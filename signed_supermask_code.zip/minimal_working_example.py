import experiment_looper

path_to_config = "./configs/fcn_sample_config.yaml"

experiment_looper.main_pipeline(path_to_config)